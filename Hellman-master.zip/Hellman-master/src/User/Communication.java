/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package User;

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;



/**
 *
 * @author Mauricio
 */
public class Communication {
      private ObjectInputStream in;
      private ObjectOutputStream out;
      public Communication(InputStream in,OutputStream out) throws IOException {
          this.in=new ObjectInputStream(in);
          this.out=new ObjectOutputStream(out);
      }
     
      public  void sentMessage(Message m) throws IOException{
          out.writeObject((Object)m);
      }
      
      public Message readMessage() throws IOException, ClassNotFoundException{
          return (Message)in.readObject();
      }
      
    
}

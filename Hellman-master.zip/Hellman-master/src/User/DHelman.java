/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package User;

import java.math.BigInteger;

/**
 *
 * @author mauricio
 */
public class DHelman {
    
    private BigInteger primeNum;
    private BigInteger gen;
    private int prvNum;
   
    
    public DHelman(BigInteger primeNum,BigInteger gen,int pv){
        this.primeNum=primeNum;
        this.gen=gen;
        this.prvNum=pv;
    }
    
    public BigInteger getKval(){
        return gen.pow(prvNum).mod(primeNum);
               
        
    }

    public BigInteger getkey(BigInteger kvb){
        return kvb.pow(prvNum).mod(primeNum);
              
    }

    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package User;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;



/**
 *
 * @author Mauricio
 */
public class User {
    public Socket s;
    private ObjectInputStream in;
    private ObjectOutputStream out;
   

 

   
    
    public User(String dir,int port) throws IOException{
       s=new Socket(dir,port);
       //initCom();
   }
    public User(Socket s) throws IOException{
       this.s=s;
      
   }
   public  void sentMessage(Message m) throws IOException{
        ObjectOutputStream out=new ObjectOutputStream(s.getOutputStream());  
        out.writeObject((Object)m);
        
       //out.close();
        //out.flush();
      }
      
      public Message readMessage() throws IOException, ClassNotFoundException{
          ObjectInputStream in; in=new ObjectInputStream(s.getInputStream());
          Object o =in.readObject();
         //in.close();
         //out.flush();
          return (Message)o;
      }
      
      public String getDesc(){
          return  s.getInetAddress().getCanonicalHostName();
      }
      
   
    
}
